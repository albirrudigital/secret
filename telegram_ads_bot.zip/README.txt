
# Telegram Bot Pemantau Facebook Ads

## Deskripsi
Bot ini membaca file `meta_ads_real_sample.csv` dan mengirim 3 iklan aktif terbaru ke Telegram.

## Cara Menjalankan

1. Install dependensi:
   pip install python-telegram-bot pandas

2. Jalankan skrip:
   python ads_bot.py

## File:
- ads_bot.py : Skrip utama bot
- meta_ads_real_sample.csv : Data iklan real (simulasi)
