
import pandas as pd
from telegram import Bot

# Konfigurasi Token dan Chat ID
TELEGRAM_TOKEN = "7877518880:AAFXPRgA5XMrM8bawrtbv0pB0M1EQCmJbM"
CHAT_ID = "7759663507"

# Muat data iklan
df = pd.read_csv("meta_ads_real_sample.csv")
ads = df[df["Active"] == True].head(3)

# Kirim pesan via Telegram
bot = Bot(token=TELEGRAM_TOKEN)
for _, row in ads.iterrows():
    message = f"""
📣 *Iklan Baru Terdeteksi*

📄 *Page:* {row['Page Name']}
🌍 *Negara:* {row['Country']}
📝 *Iklan:* {row['Ad Text']}
🔗 [Lihat di Ads Library]({row['Ad Snapshot URL']})
🗓️ *Tanggal Mulai:* {row['Start Date']}
"""
    bot.send_message(chat_id=CHAT_ID, text=message, parse_mode="Markdown")
