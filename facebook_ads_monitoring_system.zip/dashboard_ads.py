
import streamlit as st
import pandas as pd

df = pd.read_csv("meta_ads_real_sample.csv")

st.set_page_config(page_title="Facebook Ads Dashboard", layout="wide")

st.title("📊 Facebook Ads Monitoring Dashboard")

col1, col2 = st.columns(2)
col1.metric("Jumlah Iklan", len(df))
col2.metric("Iklan Aktif", df['Active'].sum())

st.subheader("📍 Distribusi Negara")
st.bar_chart(df['Country'].value_counts())

st.subheader("📰 Tabel Iklan Facebook")
st.dataframe(df[['Page Name', 'Country', 'Ad Text', 'Active', 'Ad Snapshot URL']])
