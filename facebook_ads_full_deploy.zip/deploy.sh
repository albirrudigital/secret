
#!/bin/bash
# deploy.sh - Auto setup Facebook Ads Monitoring System

echo "📦 Memulai instalasi dependencies..."
sudo apt update && sudo apt install -y python3 python3-pip nginx certbot python3-certbot-nginx

echo "📁 Pindah ke direktori proyek..."
cd /home/aphekaliinux/facebook-ads-monitoring/

echo "📦 Install Python requirements..."
pip3 install -r requirements.txt

echo "⚙️ Setup Systemd service..."
sudo cp ads_dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable ads_dashboard
sudo systemctl start ads_dashboard

echo "🌐 Setup NGINX config..."
sudo cp nginx_ads_dashboard.conf /etc/nginx/sites-available/ads_dashboard
sudo ln -s /etc/nginx/sites-available/ads_dashboard /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl restart nginx

echo "🔐 Menjalankan Certbot SSL untuk domain ads.tritunggalpancabuana.com..."
sudo certbot --nginx -d ads.tritunggalpancabuana.com

echo "✅ Deploy selesai! Dashboard dapat diakses di https://ads.tritunggalpancabuana.com"
