
#!/bin/bash
# snapshot.sh - Simulasi backup VPS snapshot (manual atau melalui API provider)

echo "⚠️  Silakan gunakan fitur snapshot dari provider VPS Anda (contoh: panel DigitalOcean, Vultr, AWS, dsb.)"
echo "📦 Pastikan file database ads_log.db dan folder project dibackup secara manual juga:"
echo "    tar -czvf fbads_backup_$(date +%Y%m%d).tar.gz /home/aphekaliinux/facebook-ads-monitoring/"
