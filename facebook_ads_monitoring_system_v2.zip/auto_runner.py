
import pandas as pd
from telegram import Bot
import schedule
import time
import sqlite3
from datetime import datetime

# Konfigurasi
TELEGRAM_TOKEN = "7877518880:AAFXPRgA5XMrM8bawrtbv0pB0M1EQCmJbM"
CHAT_ID = "7759663507"
CSV_PATH = "meta_ads_real_sample.csv"
DB_PATH = "ads_log.db"

def log_to_sqlite(ad):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        page_name TEXT,
        country TEXT,
        ad_text TEXT,
        url TEXT,
        sent_at TEXT
    )""")
    c.execute("""INSERT INTO ads (page_name, country, ad_text, url, sent_at)
                 VALUES (?, ?, ?, ?, ?)""",
              (ad['Page Name'], ad['Country'], ad['Ad Text'], ad['Ad Snapshot URL'], datetime.now().isoformat()))
    conn.commit()
    conn.close()

def run_bot():
    df = pd.read_csv(CSV_PATH)
    active_ads = df[df["Active"] == True].head(3)
    bot = Bot(token=TELEGRAM_TOKEN)

    for _, row in active_ads.iterrows():
        message = f"""
📣 *Iklan Baru Terdeteksi*

📄 *Page:* {row['Page Name']}
🌍 *Negara:* {row['Country']}
📝 *Iklan:* {row['Ad Text']}
🔗 [Lihat di Ads Library]({row['Ad Snapshot URL']})
🗓️ *Tanggal Mulai:* {row['Start Date']}
"""
        bot.send_message(chat_id=CHAT_ID, text=message, parse_mode="Markdown")
        log_to_sqlite(row)

# Jalankan setiap jam
schedule.every(1).hours.do(run_bot)

print("⏳ Bot pemantau Facebook Ads berjalan. Tekan Ctrl+C untuk berhenti.")
run_bot()

while True:
    schedule.run_pending()
    time.sleep(1)
